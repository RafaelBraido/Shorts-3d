#!/bin/sh
cd "$(dirname "$0")"
chmod +x ./FishIt.x86_64
exec ./FishIt.x86_64 --rendering-method gl_compatibility --rendering-driver opengl3 "$@"
