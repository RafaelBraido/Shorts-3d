@echo off
start "" "%~dp0FishIt.exe" --rendering-method gl_compatibility --rendering-driver opengl3
